import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { differenceInDays, differenceInHours } from 'date-fns';

// Mock historical data builder
const generateHistory = () => {
  const data = [];
  const now = new Date();
  for (let i = 24; i >= 0; i--) {
    data.push({
      time: new Date(now.getTime() - i * 5 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      temperature: parseFloat((37 + Math.random() * 1.5 - 0.5).toFixed(1)), // 36.5 - 38.0
      humidity: parseFloat((48 + Math.random() * 10 - 2).toFixed(1)), // 46.0 - 56.0
    });
  }
  return data;
};

export function useIncubatorData() {
  const [data, setData] = useState({
    startDate: null, // ISO string
    sessionActive: false,
    elapsedDays: 0,
    elapsedHours: 0,
    temperature: 37.5,
    humidity: 55,
    waterLevel: true, // true = safe, false = empty
    lastTurnTimestamp: new Date().toISOString(),
    actuators: {
      heater: false,
      fan: false,
      pump: false,
      servo: false,
    },
    history: generateHistory(),
  });

  const startNewIncubation = async () => {
    const now = new Date().toISOString();
    // Supabase snippet placeholder
    /*
    const { error } = await supabase.from('settings').update({ start_date: now }).eq('id', 1);
    if (!error) { ... }
    */
    setData(prev => ({
      ...prev,
      startDate: now,
      sessionActive: true,
      lastTurnTimestamp: now,
    }));
  };

  const stopIncubation = async () => {
    // Supabase snippet placeholder
    /*
    await supabase.from('settings').update({ start_date: null }).eq('id', 1);
    */
    setData(prev => ({
      ...prev,
      startDate: null,
      sessionActive: false,
      elapsedDays: 0,
      elapsedHours: 0,
    }));
  };

  useEffect(() => {
    let timerInterval;
    if (data.sessionActive && data.startDate) {
      timerInterval = setInterval(() => {
        const start = new Date(data.startDate);
        const now = new Date();
        const days = differenceInDays(now, start);
        // We get total elapsed hours, then modulo 24 for the remaining hours in the current day
        const hours = differenceInHours(now, start) % 24;
        
        setData(prev => {
          if (prev.elapsedDays !== days || prev.elapsedHours !== hours) {
             return { ...prev, elapsedDays: days, elapsedHours: hours };
          }
          return prev;
        });
      }, 1000); // Check every second for UI snappiness
    }
    return () => clearInterval(timerInterval);
  }, [data.sessionActive, data.startDate]);

  useEffect(() => {
    // Simulated realtime data update interval
    const interval = setInterval(() => {
      setData((prev) => {
        // If system is off, turn things off
        if (!prev.sessionActive) {
           return {
             ...prev,
             temperature: parseFloat(Math.max(25, prev.temperature - 0.2).toFixed(1)),
             humidity: parseFloat(Math.max(40, prev.humidity - 1).toFixed(1)),
             actuators: { heater: false, fan: false, pump: false, servo: false }
           };
        }

        const newTemp = parseFloat((prev.temperature + (Math.random() * 0.4 - 0.2)).toFixed(1));
        const newHum = parseFloat((prev.humidity + (Math.random() * 2 - 1)).toFixed(1));
        
        // Define ranges dynamically based on phase
        const isHatchingPhase = prev.elapsedDays >= 18;
        const targetHum = isHatchingPhase ? 65 : 55;
        
        const heaterOn = newTemp < 37.2;
        const fanOn = newTemp > 37.8 || newHum > targetHum + 5;
        const pumpOn = newHum < targetHum - 2;
        
        // Servo turns periodically in days 1-18.
        const isTurning = !isHatchingPhase && Math.random() > 0.8;

        // Keep temp and hum somewhat bounded
        const boundedTemp = Math.max(36.0, Math.min(39.0, newTemp));
        const boundedHum = Math.max(40, Math.min(70, newHum));

        const now = new Date();
        const newHistory = [...prev.history.slice(1), {
          time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          temperature: boundedTemp,
          humidity: boundedHum,
        }];

        return {
          ...prev,
          temperature: boundedTemp,
          humidity: boundedHum,
          waterLevel: Math.random() > 0.05, // 5% chance of empty
          lastTurnTimestamp: isTurning ? now.toISOString() : prev.lastTurnTimestamp,
          actuators: {
            heater: heaterOn,
            fan: fanOn,
            pump: pumpOn,
            servo: isTurning, // Servo flag
          },
          history: newHistory,
        };
      });
    }, 3000); // update every 3 seconds for demo purposes

    return () => clearInterval(interval);
  }, []);

  return { data, startNewIncubation, stopIncubation };
}
