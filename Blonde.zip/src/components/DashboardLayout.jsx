import React from 'react';
import { Activity } from 'lucide-react';

export function DashboardLayout({ children }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 p-4 sm:p-6 lg:p-8 font-sans selection:bg-slate-700">
      <div className="max-w-7xl mx-auto space-y-6">
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-6">
          <div>
            <h1 className="text-3xl font-light text-white tracking-tight">Incubator <span className="font-semibold text-slate-100">Dash</span></h1>
            <p className="text-slate-400 text-sm mt-1">Real-time Telemetry & Diagnostics</p>
          </div>
          <div className="flex items-center gap-3 bg-emerald-500/10 text-emerald-400 px-5 py-2.5 rounded-full border border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.15)]">
            <Activity className="w-4 h-4 animate-pulse" />
            <span className="text-sm font-bold tracking-wider uppercase">System Status: Auto-Mode Active</span>
          </div>
        </header>

        <main className="space-y-6">
          {children}
        </main>
      </div>
    </div>
  );
}
