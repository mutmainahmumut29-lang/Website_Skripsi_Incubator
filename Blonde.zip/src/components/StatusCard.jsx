import React from 'react';
import { Container, RotateCw } from 'lucide-react';
import { cn } from '../lib/utils';
import { formatDistanceToNow } from 'date-fns';

export function StatusCard({ title, value, type }) {
  let icon = null;
  let colorClass = "text-slate-200";
  let displayValue = value;

  if (type === 'water') {
    icon = <Container className="w-5 h-5 text-slate-400" />;
    if (value === true) {
      displayValue = "Safe";
      colorClass = "text-emerald-400";
    } else {
      displayValue = "Empty / Refill Needed";
      colorClass = "text-rose-400 animate-pulse";
    }
  } else if (type === 'tray') {
    icon = <RotateCw className="w-5 h-5 text-slate-400" />;
    try {
      displayValue = formatDistanceToNow(new Date(value), { addSuffix: true });
    } catch {
      displayValue = "Just now";
    }
    colorClass = "text-blue-400";
  }

  return (
    <div className="rounded-2xl bg-slate-900 border border-white/5 p-6 shadow-xl flex items-center justify-between transition-colors duration-300">
      <div className="flex items-center gap-4">
        <div className="p-3 bg-slate-800 rounded-xl border border-white/5 shadow-inner">
          {icon}
        </div>
        <div className="flex flex-col">
          <span className="text-slate-400 text-xs font-semibold tracking-widest uppercase mb-1">{title}</span>
          <span className={cn("text-lg font-semibold", colorClass)}>{displayValue}</span>
        </div>
      </div>
    </div>
  );
}
